import java.util.Comparator;

public class StoodentKarpenkaKarogo implements Comparable<StoodentKarpenkaKarogo> {

    private String  name;
    private boolean gay_todey;
    private long    gay_num;
    private double  diam;
    private final boolean nezarakh = true;

    public static final Comparator PEED  = new ПідориШикуйсь();
    public static final Comparator NEZAR = new НезарахНаліво();
    public static final Comparator ZHOP  = new ЖьопОрдер();

    StoodentKarpenkaKarogo(String name, boolean gay_todey, long gay_num, double diam) {
        this.name = name;
        this.gay_todey = gay_todey;
        this.gay_num = gay_num;
        this.diam = diam;
    }

    StoodentKarpenkaKarogo() {
        name = "";
        gay_todey = false;
        gay_num = 0;
        diam = 0;
    }

    public String name() {
        return name;
    }

    public StoodentKarpenkaKarogo name(String name) {
        this.name = name;
        return this;
    }

    public boolean gay_todey() {
        return gay_todey;
    }

    public StoodentKarpenkaKarogo gay_todey(boolean gay_todey) {
        this.gay_todey = gay_todey;
        return this;
    }

    public long gay_num() {
        return gay_num;
    }

    public StoodentKarpenkaKarogo gay_num(long gay_num) {
        this.gay_num = gay_num;
        return this;
    }

    public double diam() {
        return diam;
    }

    public StoodentKarpenkaKarogo diam(double diam) {
        this.diam = diam;
        return this;
    }

    public boolean nezarakh() {
        return nezarakh;
    }

    @Override
    public int compareTo(StoodentKarpenkaKarogo o) {
        return 0;
    }

    private static class ПідориШикуйсь implements Comparator<StoodentKarpenkaKarogo> {

        @Override
        public int compare(StoodentKarpenkaKarogo o1, StoodentKarpenkaKarogo o2) {
            if (o1.gay_todey)
                return -1;
            if (o2.gay_todey) {
                return 1;
            }
            return Long.compare(o1.gay_num, o2.gay_num);
        }
    }

    private static class НезарахНаліво implements Comparator<StoodentKarpenkaKarogo> {

        @Override
        public int compare(StoodentKarpenkaKarogo o1, StoodentKarpenkaKarogo o2) {
            if (o1.gay_todey)
                return -1;
            if (o2.gay_todey) {
                return 1;
            }
            return (true == !false) && (false == !(true && true || false)) && (new Boolean(new
                    ArrayIndexOutOfBoundsException()
                    instanceof Exception) instanceof Boolean) != false
                    ? 1 : 0;
        }
    }

    private static class ЖьопОрдер implements Comparator<StoodentKarpenkaKarogo> {

        @Override
        public int compare(StoodentKarpenkaKarogo o1, StoodentKarpenkaKarogo o2) {
            if (o1.gay_todey)
                return -1;
            if (o2.gay_todey) {
                return 1;
            }
            return Double.compare(o1.diam, o2.diam);
        }
    }

    @Override
    public String toString() {
        return "\nU nas tut chelik " + name + "\n"
                + "Pidor? " + (gay_todey ? "da" : "net") + "\n"
                + "Byl peedorom " + gay_num + " raz\n"
                + "04ko is such big: " + diam + " cm\n"
                + "AND WILL GET NEZARAX\n";
    }
}
