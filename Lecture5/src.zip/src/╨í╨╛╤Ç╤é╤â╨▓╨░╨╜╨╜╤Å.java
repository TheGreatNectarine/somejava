import java.util.Comparator;

public class Сортування {

    @SuppressWarnings("unchecked")
    public static Comparable[] вставкою(Comparable[] input, Comparator c) {
        Comparable temp;
        for (int i = 1; i < input.length; i++) {
            for (int j = i; j > 0; j--) {
                if (c.compare(input[j], input[j - 1]) > 0) {
                    temp = input[j];
                    input[j] = input[j - 1];
                    input[j - 1] = temp;
                }
            }
        }
        return input;
    }

    @SuppressWarnings("unchecked")
    public static Comparable[] вибором(Comparable[] arr, Comparator c) {
        for (int i = 0; i < arr.length - 1; i++) {
            int index = i;
            for (int j = i + 1; j < arr.length; j++)
                if (c.compare(arr[j], arr[index]) > 0)
                    index = j;
            ексщчь(c, arr[index], arr[i]);
        }
        return arr;
    }

    @SuppressWarnings("unchecked")
    private static void ексщчь(Comparator c, Comparable c1, Comparable c2) {
        if (c.compare(c1, c2) > 0) {
            Comparable temp = c1;
            c1 = c2;
            c2 = temp;
        }
    }

    public static void злиттям(Comparable[] a) {
        Comparable[] tmp = new Comparable[a.length];
        злиттям(a, tmp, 0, a.length - 1);
    }


    private static void злиттям(Comparable[] a, Comparable[] tmp, int left, int right) {
        if (left < right) {
            int center = (left + right) / 2;
            злиттям(a, tmp, left, center);
            злиттям(a, tmp, center + 1, right);
            злити(a, tmp, left, center + 1, right);
        }
    }

    @SuppressWarnings("unchecked")
    private static void злити(Comparable[] a, Comparable[] tmp, int left, int right, int rightEnd) {
        int leftEnd = right - 1;
        int k       = left;
        int num     = rightEnd - left + 1;

        while (left <= leftEnd && right <= rightEnd)
            if (a[left].compareTo(a[right]) <= 0)
                tmp[k++] = a[left++];
            else
                tmp[k++] = a[right++];

        while (left <= leftEnd)
            tmp[k++] = a[left++];

        while (right <= rightEnd)
            tmp[k++] = a[right++];

        for (int i = 0; i < num; i++, rightEnd--)
            a[rightEnd] = tmp[rightEnd];
    }
}
